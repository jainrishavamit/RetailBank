package com.tcs.ilp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.ilp.bean.SearchExist;
import com.tcs.ilp.service.SearchService;

public class SearchExistServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException,ServletException{
		String custId = request.getParameter("custId");
		String accId =  request.getParameter("accId");
		SearchExist search = new SearchExist();
		
		if(custId.length()==0)
		{
			search.setAccId(Long.parseLong(accId));
			search.setCustId(0);
		}
		else if(accId.length()==0)
		{
			search.setCustId(Long.parseLong(custId));
			search.setAccId(0);
			
		}
		else
		{
			search.setAccId(Long.parseLong(accId));
			search.setCustId(Long.parseLong(custId));
		}
		SearchService serve = new SearchService();
		if(serve.findId(search))
		{
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/NewCust.html");
			PrintWriter out = response.getWriter();
			out.println("<font color=green> User Found </font>");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/NewCust.html");
			PrintWriter out = response.getWriter();
			out.println("<font color=red> User Not Found </font>");
			rd.include(request, response);
		}
	}
}
