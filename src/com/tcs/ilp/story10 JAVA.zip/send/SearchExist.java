package com.tcs.ilp.bean;

public class SearchExist {

	private long CustId;
	private long AccId;
	public long getCustId() {
		return CustId;
	}
	public void setCustId(long custId) {
		CustId = custId;
	}
	public long getAccId() {
		return AccId;
	}
	public void setAccId(long accId) {
		AccId = accId;
	}
	
}
