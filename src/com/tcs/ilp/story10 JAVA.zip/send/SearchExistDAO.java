package com.tcs.ilp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tcs.ilp.bean.SearchExist;
import com.tcs.ilp.util.DBConnection;

public class SearchExistDAO {

	public boolean custexist(SearchExist search) {
		long custId = search.getCustId();
		long accId = search.getAccId();
		
		if(custId==0)
		{
				Connection con=DBConnection.createConnection();
				PreparedStatement ps;
				try {
					ps = con.prepareStatement("SELECT AI_Acc_ID FROM `account_info` WHERE AI_Acc_ID like ?");
					ps.setLong(1, accId);
					ResultSet rs=ps.executeQuery();
					if(rs.next()) {return true;}else {return false;}
				} catch (SQLException e) {e.printStackTrace();}
				
		}
		else if(accId==0)
		{
			Connection con=DBConnection.createConnection();
			PreparedStatement ps;
			try {
				ps = con.prepareStatement("SELECT CI_Customer_ID FROM `customer_info` WHERE CI_Customer_ID like ?");
				ps.setLong(1, accId);
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {return true;}else {return false;}
			} catch (SQLException e) {e.printStackTrace();}
		}
		else
		{
			Connection con=DBConnection.createConnection();
			PreparedStatement ps;
			try {
				ps = con.prepareStatement("SELECT * FROM `account_info` WHERE AI_Acc_ID like ? AND AI_Cus_ID like ?");
				ps.setLong(1, accId);
				ps.setLong(2, custId);
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {return true;}else {return false;}
			} catch (SQLException e) {e.printStackTrace();}
		}
		
		return false;
	}
}